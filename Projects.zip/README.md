# Docker run project

* docker compose up -d
# -----The best command-------
```
docker-compose up --build -d
docker compose down
```

## Working docker Hub
```
docker compose stop
docker login
docker-compose pull
docker compose up -d
```